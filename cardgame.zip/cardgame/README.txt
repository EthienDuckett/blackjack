Available controls
click on deck to draw
click on Challenge to compare the dealer's hand to yours
click on play again? to play again
The deck will be shuffled automatically or if it is your turn you can probably click on where the deck should be to re-generate the deck if it doesn't generate automatically


Created by Ethien Duckett, special thanks to pyglet.org for having a GUI I could learn quickly


My website http://ejware.com
My github https://github.com/EthienDuckett
My coding discord group https://discord.gg/b5up2MF
My email ethienduckett@outlook.com

No selling software that I create under any circumstances
If there is any kind of folder or executable that just runs python3 programs without needing python3 installed, I would like to know about it

Trouble shooting:
In the event this program does not work make sure you have python 3.8 with the modules time and random. If you have those then it may be the pyglet module. If you believe it is delete the folder "pyglet" and install it using pip/pip3 install pyglet


How to use:
go to the terminal, change directories to where the file is located, probably in downloads and type 'python3 blackjack.py'

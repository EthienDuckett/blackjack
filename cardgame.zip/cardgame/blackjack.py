import pyglet
import random
import time

def remainder(num, divisor):
    if num < divisor:
        return num
    else:
        while num > -1:
            num-=divisor

        return num+divisor
class GameWindow(pyglet.window.Window):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.set_location(330, 140)
        self.placeholder=0
        self.background=pyglet.image.load("resources/background.png")
        self.cardbody=pyglet.image.load("resources/cardbody.png")
        self.cardback=pyglet.image.load("resources/cardback.png")
        self.restart=pyglet.image.load("resources/restart.png")
        self.challenge=pyglet.image.load("resources/challenge.png")
        # self.shuffle=pyglet.image.load("resources/restart.png")
        self.hwim=(self.restart.width, self.restart.height, self.challenge.width, self.challenge.height)
        print(self.hwim[1])
        self.dealeryaxis=430
        self.playeryaxis=30
        self.dealerxaxis=[300, 350, 400, 450, 500]
        self.playerxaxis=[300, 350, 400, 450, 500]
        self.deck=[]
        for i in range(0, 52):
            self.deck.append(i)
        print(list(self.deck))
        self.deckl=51
        self.playerhand=[]
        self.dealerhand=[]
        # self.drawcolhand=(0,0,0,0,0)

        # for text
        self.cards=[0,0,0,0,0]
        self.drawcards=pyglet.graphics.Batch()
        self.cardsd=[0,0,0,0,0]
        self.drawcardsd=pyglet.graphics.Batch()

        # for actual cards
        self.cards1=[0,0,0,0,0]
        self.drawcards1=pyglet.graphics.Batch()
        self.cardsd1=[0,0,0,0,0]
        self.drawcardsd1=pyglet.graphics.Batch()

        self.decksused=0

        self.dealersum=0
        self.playersum=0
        self.playersumalt=0

        self.ace=[0, 0]
        self.win=[0, 0]
        self.bool=False

    def on_draw(self):
        self.clear()
        self.background.blit(0, 0)
        i=len(self.playerhand)
        for a in range(0,i):
            self.cardbody.blit(self.playerxaxis[a],self.playeryaxis)
        # i=len(self.dealerhand)
        # for a in range(0,i):
        #     self.cardback.blit(self.dealerxaxis[a],self.dealeryaxis)
        if len(self.dealerhand) > 0:
            self.cardbody.blit(x=self.dealerxaxis[0],y=self.dealeryaxis)
        self.drawcardsd1.draw()
        self.drawcards.draw()
        self.drawcardsd.draw()
        pyglet.text.Label("decks used: "+str(self.decksused), x=400, y=335).draw()
        pyglet.text.Label("Your wins: "+str(self.win[0]), x=30, y=50).draw()
        pyglet.text.Label("Dealer wins: "+str(self.win[1]), x=30, y=660).draw()
        pyglet.text.Label("Your count: "+str(self.playersum)+"/"+str(self.playersumalt), x=30, y=30).draw()

        if self.deckl != 0:
            self.cardback.blit(20, 231)
        self.restart.blit(200, 335)
        self.challenge.blit(670 ,335)
        if self.deckl+len(self.playerhand)+len(self.dealerhand) < 51:
            self.cardbody.blit(810, 231)

    def update(self, dt):
        self.placeholder=0

    # handle the player's actions
    def on_mouse_press(self, x, y, button, modifiers):
        if button == pyglet.window.mouse.LEFT:

            if x>19 and x<191 and y>230 and y<461 and self.bool==False:
                if self.deckl > 0 and len(self.playerhand) < 5 and self.playersum<21:
                    random.seed(time.time())
                    i=random.randint(0, self.deckl)
                    self.playerhand.append(self.deck[i])
                    # print(self.deck[i])
                    self.deck.pop(i)
                    self.deckl-=1
                    GameWindow.gen_cards(self)

                if self.deckl > 0 and len(self.dealerhand) < 5 and self.dealersum<18:
                    random.seed(time.time())
                    i=random.randint(0, self.deckl)
                    self.dealerhand.append(self.deck[i])
                    # print(self.deck[i])
                    self.deck.pop(i)
                    self.deckl-=1
                    GameWindow.gen_cardsd(self, car="hide")
                if self.deckl == 0:
                    GameWindow.shuffle(self)
                    self.deckl=len(self.deck)-1
                    self.decksused+=1

            if self.deckl == 0 and len(self.playerhand) < 5 and self.playersum<21:
                print(self.playersum)
            elif x > 199 and x < 200+self.hwim[0] and y > 334 and y < 335+self.hwim[1]:
                print("restart")
                self.ace=[0, 0]
                self.bool=False
                self.playerhand=[]
                self.dealerhand=[]
                self.playersum=0
                self.playersumalt=0
                self.dealersum=0
                GameWindow.gen_cards(self)
                GameWindow.gen_cardsd(self, car="hide")
                # GameWindow.gen_cards(self)
            elif x > 679 and x < 680+self.hwim[2] and y > 334 and y < 335+self.hwim[3] and self.bool==False:
                self.bool=True
                print("challenge")
                for i in range(0, 5):
                    if self.deckl > 0 and len(self.dealerhand) < 5 and self.dealersum<18:
                        random.seed()
                        i=random.randint(0, self.deckl)
                        self.dealerhand.append(self.deck[i])
                        self.deck.pop(i)
                        self.deckl-=1
                        GameWindow.gen_cardsd(self, car="hide")

                    if self.deckl == 0:
                        GameWindow.shuffle(self)
                        self.deckl=len(self.deck)-1
                        self.decksused+=1
                GameWindow.gen_cardsd(self, car="show")

                if self.playersumalt < 22 and self.playersumalt != 0:
                    self.playersum=self.playersumalt


                if self.dealersum > 21 and self.playersum > 21:
                    print()
                elif len(self.dealerhand) > 4 or len(self.playerhand) > 4:
                    if len(self.dealerhand) > len(self.playerhand):
                        self.win[1]+=1
                    elif len(self.dealerhand) < len(self.playerhand):
                        self.win[0]+=1
                    elif self.playersum < 22 and self.dealersum < 22:
                        if self.playersum > self.dealersum:
                            self.win[0]+=1
                        elif self.playersum < self.dealersum:
                            self.win[1]+=1
                        else:
                            print("bust")
                    elif self.playersum < 22 and self.dealersum > 21:
                        self.win[0]+=1
                    elif self.playersum > 21 and self.dealersum < 22:
                        self.win[1]+=1
                elif self.dealersum == self.playersum:
                    print("tie")
                elif self.dealersum > self.playersum and self.dealersum < 22:
                    self.win[1]+=1
                elif self.dealersum < self.playersum and self.playersum < 22:
                    self.win[0]+=1

                elif self.dealersum < 22:
                    self.win[1]+=1
                elif self.playersum < 22:
                    self.win[0]+=1
                print("dealersum= "+str(self.dealersum))

    def shuffle(self):
        self.deck=[]
        for i in range(0, 52):
            self.deck.append(i)
        while i in self.playerhand:
            self.deck.pop[i]
        while i in self.dealerhand:
            self.deck.pop[i]

    def gen_cardsd(self, car):
        self.cardsd=[0,0,0,0,0]
        self.drawcardsd=pyglet.graphics.Batch()
        sum=0
        i=len(self.dealerhand)
        # car="hide"
        self.cardsd1=[0,0,0,0,0]
        self.drawcardsd1=pyglet.graphics.Batch()
        if car == "show":
            div=self.cardbody
        elif car == "hide":
            div=self.cardback
        for a in range(0,i):
            if a>0:
                self.cardsd1[a]=pyglet.sprite.Sprite(div,x=self.dealerxaxis[a],y=self.dealeryaxis, batch=self.drawcardsd1)
            num=self.dealerhand[a]
            if num<13:
                faction="club"
                col=(0, 0, 0, 255)
            elif num>12 and num<26:
                faction="heart"
                col=(255, 0, 0, 255)
            elif num>25 and num<39:
                faction="spade"

                col=(0, 0, 0, 255)
            elif num>38:
                faction="diamond"
                col=(255, 0, 0, 255)
            id=0
            id=remainder(num,13)

            if id==0:
                if car == "show" or a == 0:
                    text=pyglet.text.Label("2", x=self.dealerxaxis[a]+10, y=self.dealeryaxis+210, color=col, batch=self.drawcardsd)
                sum+=2
            elif id==1:
                if car == "show" or a == 0:
                    text=pyglet.text.Label("3", x=self.dealerxaxis[a]+10, y=self.dealeryaxis+210, color=col, batch=self.drawcardsd)
                sum+=3
            elif id==2:
                if car == "show" or a == 0:
                    text=pyglet.text.Label("4", x=self.dealerxaxis[a]+10, y=self.dealeryaxis+210, color=col, batch=self.drawcardsd)
                sum+=4
            elif id==3:
                if car == "show" or a == 0:
                    text=pyglet.text.Label("5", x=self.dealerxaxis[a]+10, y=self.dealeryaxis+210, color=col, batch=self.drawcardsd)
                sum+=5
            elif id==4:
                if car == "show" or a == 0:
                    text=pyglet.text.Label("6", x=self.dealerxaxis[a]+10, y=self.dealeryaxis+210, color=col, batch=self.drawcardsd)
                sum+=6
            elif id==5:
                if car == "show" or a == 0:
                    text=pyglet.text.Label("7", x=self.dealerxaxis[a]+10, y=self.dealeryaxis+210, color=col, batch=self.drawcardsd)
                sum+=7
            elif id==6:
                if car == "show" or a == 0:
                    text=pyglet.text.Label("8", x=self.dealerxaxis[a]+10, y=self.dealeryaxis+210, color=col, batch=self.drawcardsd)
                sum+=8
            elif id==7:
                if car == "show" or a == 0:
                    text=pyglet.text.Label("9", x=self.dealerxaxis[a]+10, y=self.dealeryaxis+210, color=col, batch=self.drawcardsd)
                sum+=9
            elif id==8:
                if car == "show" or a == 0:
                    text=pyglet.text.Label("10", x=self.dealerxaxis[a]+10, y=self.dealeryaxis+210, color=col, batch=self.drawcardsd)
                sum+=10
            elif id==9:
                if car == "show" or a == 0:
                    text=pyglet.text.Label("J", x=self.dealerxaxis[a]+10, y=self.dealeryaxis+210, color=col, batch=self.drawcardsd)
                sum+=10
            elif id==10:
                if car == "show" or a == 0:
                    text=pyglet.text.Label("Q", x=self.dealerxaxis[a]+10, y=self.dealeryaxis+210, color=col, batch=self.drawcardsd)
                sum+=10
            elif id==11:
                if car == "show" or a == 0:
                    text=pyglet.text.Label("K", x=self.dealerxaxis[a]+10, y=self.dealeryaxis+210, color=col, batch=self.drawcardsd)
                sum+=10
            elif id==12:
                if car == "show" or a == 0:
                    text=pyglet.text.Label("A", x=self.dealerxaxis[a]+10, y=self.dealeryaxis+210, color=col, batch=self.drawcardsd)
                sum+=1
                self.ace[1]=1

                sum+=10
            if sum > 21 and self.ace[1]==1:
                self.ace[1]=0
                sum-=10
            # else:
                # print(id)
                # print(self.dealerhand[a])
            # print(id)
            del id
            del num
            self.dealersum=sum
            if car == "show" or a == 0:
                self.cardsd[a]=text

    # def show_cardsd(self):

    def gen_cards(self):
        self.cards=[0,0,0,0,0]
        self.drawcards=pyglet.graphics.Batch()
        sum=0
        i=len(self.playerhand)
        for a in range(0,i):
            self.cardbody.blit(self.playerxaxis[a],self.playeryaxis)
            num=self.playerhand[a]
            if num<13:
                faction="club"
                col=(0, 0, 0, 255)
            elif num>12 and num<26:
                faction="heart"
                col=(255, 0, 0, 255)
            elif num>25 and num<39:
                faction="spade"

                col=(0, 0, 0, 255)
            elif num>38:
                faction="diamond"
                col=(255, 0, 0, 255)
            id=0
            id=remainder(num,13)

            if id==0:
                text=pyglet.text.Label("2", x=self.playerxaxis[a]+10, y=self.playeryaxis+210, color=col, batch=self.drawcards)
                sum+=2
            elif id==1:
                text=pyglet.text.Label("3", x=self.playerxaxis[a]+10, y=self.playeryaxis+210, color=col, batch=self.drawcards)
                sum+=3
            elif id==2:
                text=pyglet.text.Label("4", x=self.playerxaxis[a]+10, y=self.playeryaxis+210, color=col, batch=self.drawcards)
                sum+=4
            elif id==3:
                text=pyglet.text.Label("5", x=self.playerxaxis[a]+10, y=self.playeryaxis+210, color=col, batch=self.drawcards)
                sum+=5
            elif id==4:
                text=pyglet.text.Label("6", x=self.playerxaxis[a]+10, y=self.playeryaxis+210, color=col, batch=self.drawcards)
                sum+=6
            elif id==5:
                text=pyglet.text.Label("7", x=self.playerxaxis[a]+10, y=self.playeryaxis+210, color=col, batch=self.drawcards)
                sum+=7
            elif id==6:
                text=pyglet.text.Label("8", x=self.playerxaxis[a]+10, y=self.playeryaxis+210, color=col, batch=self.drawcards)
                sum+=8
            elif id==7:
                text=pyglet.text.Label("9", x=self.playerxaxis[a]+10, y=self.playeryaxis+210, color=col, batch=self.drawcards)
                sum+=9
            elif id==8:
                text=pyglet.text.Label("10", x=self.playerxaxis[a]+10, y=self.playeryaxis+210, color=col, batch=self.drawcards)
                sum+=10
            elif id==9:
                text=pyglet.text.Label("J", x=self.playerxaxis[a]+10, y=self.playeryaxis+210, color=col, batch=self.drawcards)
                sum+=10
            elif id==10:
                text=pyglet.text.Label("Q", x=self.playerxaxis[a]+10, y=self.playeryaxis+210, color=col, batch=self.drawcards)
                sum+=10
            elif id==11:
                text=pyglet.text.Label("K", x=self.playerxaxis[a]+10, y=self.playeryaxis+210, color=col, batch=self.drawcards)
                sum+=10
            elif id==12:
                text=pyglet.text.Label("A", x=self.playerxaxis[a]+10, y=self.playeryaxis+210, color=col, batch=self.drawcards)
                sum+=1
                self.ace[0]=1
            else:
                print(id)
                print(self.playerhand[a])
            # print(id)
            del id
            del num
            self.playersum=sum
            self.cards[a]=text
        self.playersumalt=sum
        if self.playersumalt < 12 and self.ace[0]==1:
            self.ace[0]=0
            self.playersumalt+=10



if __name__ == "__main__":
    window = GameWindow(1000, 700, "Black Jack", resizable=False)
    pyglet.clock.schedule_interval(window.update, 1/60)
    pyglet.app.run()
